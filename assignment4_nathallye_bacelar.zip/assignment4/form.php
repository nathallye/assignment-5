<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment #4</title>
  </head>
  <body>
    <h2>Assignment #4</h2>

    <form action="process.php" method="POST">
      <label for="a_value">A value:</label>
      <input type="text" id="a_value" name="a_value" required><br><br>
      <label for="b_value">B value:</label>
      <input type="text" id="b_value" name="b_value" required><br><br>
      <label for="c_value">C value:</label>
      <input type="text" id="c_value" name="c_value" required><br><br>
      <label for="d_value">D value:</label>
      <input type="text" id="d_value" name="d_value" required><br><br>
      <label for="e_value">E value:</label>
      <input type="text" id="e_value" name="e_value" required><br><br>

      <input type="submit" value="Check">
    </form>
  </body>
</html>